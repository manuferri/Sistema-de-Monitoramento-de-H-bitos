# Projeto Integrador - WiseHabit

Este é o código-fonte do projeto integrador desenvolvido em Java, usando o Eclipse IDE.

## Tecnologias
- Java
- MySQL
- JDBC

## Estrutura
- `src/`: Código-fonte da aplicação
- `lib/`: Biblioteca do conector JDBC para MySQL

## Sobre
O sistema tem como objetivo o monitoramento de hábitos de usuários, permitindo o cadastro de metas, hábitos e categorias.

## Como executar
1. Importe o projeto em uma IDE como o Eclipse.
2. Certifique-se de ter o MySQL instalado e configure o banco conforme o script original.
3. Adicione o `mysql-connector-j-9.1.0.jar` ao classpath do projeto.

