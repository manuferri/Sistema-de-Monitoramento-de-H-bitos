package util;

public class BDConfigs {

	public static final String IP = "localhost";
	public static final String PORTA = "3306";
	public static final String USUARIO = "root";
	public static final String SENHA = "@a0603@p1810";
	public static final String NOME_BD = "bd_wisehabit";
	
}
